# Multi-Agent Fetch Architecture — PSX News Monitor

## PURPOSE

Sequential web searches are slow and produce shallow coverage. This file defines a **parallel agent dispatch model**: instead of running one search at a time, Claude dispatches multiple specialized fetch agents simultaneously at the start of a SCAN query, each responsible for a specific information domain. All agents run in parallel; Claude synthesizes results once all return.

This reduces information-gathering time from 5-8 sequential searches to a single parallel round, and ensures no information domain is missed due to attention drift.

---

## WHEN TO USE THIS FILE

Load and follow this architecture for:
- **SCAN queries** (full market update) — always use full multi-agent dispatch
- **SCREEN queries** (sector-specific) — use the relevant sector agent + always MACRO AGENT + NEWS AGENT
- **SPOT queries** — use MACRO AGENT + the single most relevant sector agent only

---

## AGENT ROSTER

Each agent is a defined set of simultaneous web_search calls. Treat each agent as a parallel task. Issue all searches within an agent at the same time before processing results.

---

### AGENT 1 — MACRO AGENT (Always Active)

**Responsibility:** Core macroeconomic variables. Required for every query type.

**Searches to run simultaneously:**
```
Search 1: "SBP policy rate Pakistan 2026"
Search 2: "PKR USD interbank rate today"
Search 3: "Brent crude oil price today"
Search 4: "Pakistan CPI inflation latest 2026"
Search 5: "Pakistan IMF program status tranche 2026"
```

**Outputs to extract:**
- SBP policy rate (%) + date of last MPC decision
- PKR/USD rate + MTD change
- Brent crude USD/bbl + WTD change
- Pakistan CPI % YoY + month of reading
- IMF program tranche status + next review date

**Fallback:** If any search returns no result, flag as [unverified — check SBP.org.pk / sbp.org.pk/m_policy]

---

### AGENT 2 — PAKISTAN NEWS AGENT (Always Active for SCAN)

**Responsibility:** Domestic market news, PSX movements, government policy, regulatory announcements.

**Searches to run simultaneously:**
```
Search 1: "PSX KSE-100 news today"
Search 2: "Pakistan government economic policy announcement today"
Search 3: "NEPRA OGRA notification Pakistan March 2026"
Search 4: "Pakistan petrol diesel price today"
Search 5: "SBP Pakistan news today"
```

**Outputs to extract:**
- KSE-100 index level + daily/weekly move
- Any NEPRA, OGRA, FBR, SBP regulatory announcements
- Government fuel price notification (latest petrol/diesel PKR/litre)
- Any Budget, fiscal, or trade policy news

---

### AGENT 3 — ENERGY AGENT (Active when E&P / Refining / OMC / IPP / Fertilizer in scope)

**Responsibility:** Global and local energy market variables.

**Searches to run simultaneously:**
```
Search 1: "crude oil price today Brent WTI"
Search 2: "RLNG LNG price Pakistan 2026"
Search 3: "coal price international today USD per tonne"
Search 4: "natural gas price Pakistan OGRA notification"
Search 5: "Strait of Hormuz oil supply news today"
```

**Outputs to extract:**
- Brent/WTI current price + direction
- RLNG import price or OGRA notification (PKR/MMBTU)
- International coal price (USD/MT, Newcastle/Indonesian benchmark)
- Any Middle East / supply disruption news affecting energy

---

### AGENT 4 — CHEMICAL AGENT (Active when EPCL / ICI / NIMIR / LOTCHEM in scope)

**Responsibility:** Chemical feedstock and product pricing, trade protection, downstream demand signals.

**Searches to run simultaneously:**
```
Search 1: "PVC resin price Asia today CFR"
Search 2: "PTA paraxylene spread price today"
Search 3: "ethylene price today Asia"
Search 4: "Pakistan PVC import duty FBR 2026"
Search 5: "caustic soda price Pakistan 2026"
```

**Outputs to extract:**
- PVC CFR price (USD/MT) — key for EPCL import parity
- PTA/PX spread (USD/MT) — key for LOTCHEM margin
- Ethylene price (USD/MT) — EPCL feedstock
- Any FBR SRO on chemical import duties
- Caustic soda domestic price (PKR/MT) — EPCL co-product revenue

**Data sources to prioritize:** ICIS (icis.com), S&P Global Platts, Chemical Week

---

### AGENT 5 — BANKING & RATES AGENT (Active when Banking / Auto / IPP in scope)

**Responsibility:** Interest rate environment, yield curve, credit market signals.

**Searches to run simultaneously:**
```
Search 1: "Pakistan T-bill auction result latest 2026"
Search 2: "Pakistan PIB yield today"
Search 3: "SBP monetary policy committee next meeting date"
Search 4: "Pakistan banking sector news today"
Search 5: "Pakistan private sector credit growth SBP"
```

**Outputs to extract:**
- 3M T-Bill cutoff yield (%) + change vs. last auction
- 5Y/10Y PIB yield (%) — key for bank PIB MTM
- Next MPC meeting date
- Any banking sector regulatory news (super tax, IFRS changes, NPL data)
- Private sector credit growth YoY (%)

---

### AGENT 6 — AGRICULTURAL & COMMODITY AGENT (Active when Fertilizer / Textile / Cement in scope)

**Responsibility:** Agricultural commodity prices and crop data affecting input-heavy sectors.

**Searches to run simultaneously:**
```
Search 1: "urea fertilizer price international today"
Search 2: "cotton price Pakistan today Cotlook"
Search 3: "coal price Newcastle Australian today"
Search 4: "Pakistan NFDC fertilizer offtake data"
Search 5: "Pakistan wheat cotton crop estimate 2026"
```

**Outputs to extract:**
- International urea price (USD/MT FOB Middle East/Black Sea)
- Cotton price (USD/lb Cotlook A or PKR/maund domestic)
- Coal price (USD/MT Newcastle benchmark)
- NFDC monthly offtake (if published)
- Crop production estimates (PBS)

---

### AGENT 7 — COMPANY NEWS AGENT (Active for SCAN and when specific tickers are in scope)

**Responsibility:** Company-specific results, announcements, and news for known holdings.

**Build dynamically based on known holdings.** For each known holding, run one search:
```
Template: "[TICKER] Pakistan results announcement news 2026"
```

**Example for known portfolio (OGDC, POL, FFC, HBL, MCB, ATRL, INDU, EPCL):**
```
Search 1: "OGDC results announcement Pakistan 2026"
Search 2: "POL Pakistan Oilfields news 2026"
Search 3: "FFC Fauji Fertilizer results 2026"
Search 4: "HBL results dividend Pakistan 2026"
Search 5: "MCB Bank Pakistan results 2026"
Search 6: "ATRL Attock Refinery news 2026"
Search 7: "INDU Honda Atlas results Pakistan 2026"
Search 8: "EPCL Engro Polymer results Pakistan 2026"
```

**Outputs to extract:**
- Any announced quarterly results (EPS, DPS vs. expectations)
- Dividend announcements
- Production updates / project milestones
- PSX price-sensitive announcements

---

## DISPATCH PROTOCOL

### For SCAN Query:

**Round 1 — Parallel Dispatch (issue all at once):**
Run AGENT 1 + AGENT 2 + AGENT 3 + AGENT 5 + AGENT 6 + AGENT 7 simultaneously.

Do NOT write any output section until all agents return.

**Round 2 — Targeted Follow-up (only if needed):**
After reviewing Round 1 results:
- If a major event is identified (e.g., NEPRA notification, company results), run 1-2 targeted follow-up searches to get full details.
- If a sector is flagged as having unusual news, run the relevant sector agent (AGENT 4 for chemicals, etc.).
- Maximum 3 follow-up searches in Round 2.

**Round 3 — Synthesis:**
Write the full output using all retrieved data. Every data point must be tagged with its source agent + search query that produced it.

---

### For SCREEN Query (single sector):

**Parallel Dispatch:**
Run AGENT 1 + AGENT 2 + relevant sector agent simultaneously.
- Energy screen → AGENT 3
- Banking screen → AGENT 5
- Fertilizer/Textile/Cement screen → AGENT 6
- Chemicals screen → AGENT 4
- Auto screen → AGENT 5 (rates) + AGENT 6 (cotton for component cost)

---

### For SPOT Query (single event):

**Minimal Dispatch:**
Run AGENT 1 + the single most relevant sector agent only.
Do not run AGENT 7 (company news) unless a specific ticker is mentioned.

---

## AGENT OUTPUT LOG FORMAT

After running agents, before writing analysis, produce a compact internal log:

```
AGENT DISPATCH LOG
==================
MACRO AGENT: SBP 10.5% [source: brecorder.com] | PKR/USD 279 [source: investing.com] | Brent $107 [source: oilpriceapi.com] | CPI 7.0% Feb [source: tradingeconomics.com] | IMF $7bn active [source: bloompakistan.com]

ENERGY AGENT: RLNG [unverified — check OGRA] | Coal $120/MT [source: tradingeconomics.com] | Hormuz disruption ongoing [source: CNN/Reuters]

BANKING AGENT: T-Bill [unverified] | Next MPC May 2026 [estimated] | No major banking news found

COMPANY AGENT: OGDC — no new results | POL — no new results | FFC — no new results | HBL — [result summary if found]

GAPS: [List any agent that returned no data — these are blind spots in today's brief]
```

This log makes the data provenance transparent and tells the user exactly what was fetched vs. assumed.

---

## INFORMATION QUALITY TIERS

| Tier | Definition | Action |
|---|---|---|
| LIVE | Fetched in this session from a dated web source | Use directly; cite source |
| RECENT | Fetched from a source dated within 7 days | Use with date flag |
| STALE | Recalled from training data; no live confirmation | Always flag as [unverified — check current] |
| MISSING | Agent returned no relevant result | Flag as [data gap] in output |

**Rule:** Never present STALE or MISSING data as current fact. If a critical variable (SBP rate, PKR/USD, Brent) returns no live result, run one additional targeted search before proceeding.

---

## EFFICIENCY PRINCIPLES

1. **Parallel, not sequential** — All searches within a round are issued simultaneously. Never chain searches one at a time.
2. **Agent specialization reduces overlap** — Each agent owns its domain; no two agents run the same search.
3. **Minimum round structure** — SPOT: 1 round (5-6 searches). SCREEN: 1 round (8-10 searches). SCAN: 2 rounds (15-20 searches total). Never exceed 25 total searches.
4. **Fail fast on gaps** — If an agent returns nothing after 2 searches, flag the gap and move on. Do not spiral into endless search attempts for a single variable.
5. **Synthesis is the value** — The output is only as good as the synthesis, not the number of searches. Stop fetching when you have enough to produce actionable intelligence.
