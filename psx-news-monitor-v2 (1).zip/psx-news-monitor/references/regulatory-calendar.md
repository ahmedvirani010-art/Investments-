# Regulatory Calendar — PSX News Monitor

Key recurring dates and event cycles for the Watch List section.

---

## SBP MONETARY POLICY COMMITTEE (MPC)

Frequency: 6 meetings per year (approximately every 2 months)
Typical schedule: January, March, May, July, September, November
Announcement: Same day as meeting, press release on SBP.org.pk
Lead time for Watch List: Flag 2 weeks before scheduled MPC
Source: sbp.org.pk/monetary-policy

---

## NEPRA (National Electric Power Regulatory Authority)

Monthly FCA (Fuel Cost Adjustment): Typically issued 3rd-4th week of each month for prior month
Quarterly tariff determinations: Ongoing, triggered by DISCOs/IPPs filing
Annual Generation License reviews: Rolling calendar, company-specific
Watch: nepra.org.pk/regulation/tariff

---

## OGRA (Oil and Gas Regulatory Authority)

Petrol/diesel retail price notifications: Fortnightly (1st and 16th of each month, approximately)
RLNG price notifications: Monthly, linked to international LNG/crude
Wellhead gas price revisions: Semi-annual (typically January and July)
Watch: ogra.org.pk/press-releases

---

## IMF PROGRAM (CURRENT: EFF PROGRAM)

Board reviews: Typically quarterly
Article IV consultations: Annual
Tranche disbursements: On successful review completion
Pakistan press releases: finance.gov.pk, imf.org/pakistan

---

## FBR / TAX CALENDAR

Federal Budget: Typically first week of June
Finance Act (post-budget): August-September
SRO issuances: Rolling — monitor FBR website
Tax amnesty / sector-specific schemes: Ad hoc, budget-linked

---

## RESULT SEASONS (PSX)

Q1 (Jul-Sep): Results due October-November
Q2 (Oct-Dec) / Half Year: Results due January-February
Q3 (Jan-Mar) / Nine Months: Results due April-May
Full Year (Jul-Jun): Results due August-September

Note: Banking sector follows December year-end (CY). Non-banking follows June year-end (FY).
Banking full year results: February-March
Banking half year: August-September

---

## SECTOR DATA RELEASES

APCMA (Cement dispatches): First week of each month, prior month data
PAMA (Auto sales): First week of each month, prior month data
OCAC (Oil product sales): Monthly, typically mid-month
NFDC (Fertilizer offtake): Monthly
PBS Large Scale Manufacturing: Monthly, 6-8 week lag
PBS CPI: 1st of each month for prior month
SBP Monthly Statistical Bulletin: Mid-month release
State Bank Monetary Policy Statement: MPC meeting days

---

## COTTON / CROP CALENDAR

Cotton sowing: March-May (Kharif season begins)
Cotton picking: September-December
PCCC crop progress: Monthly during season (June-December)
Punjab/Sindh crop estimates: October-November
Rabi crop (wheat) sowing: October-November; harvest: March-April
Wheat procurement price: Typically February-March before harvest

---

## PARLIAMENTARY / BUDGET CALENDAR

Annual budget speech: First Friday of June (National Assembly)
PSDP approval: Budget session (June)
PSDP quarterly reviews: September, December, March
ECC (Economic Coordination Committee): Ad hoc, monitor Cabinet Division
CCOE (Cabinet Committee on Energy): Ad hoc, major energy policy decisions

---

## GIDC / LEGAL CALENDAR

Supreme Court benches on GIDC: No fixed schedule — monitor daily cause list
High Court orders on pharma/cement: Monitor company PSX announcements

---

## KEY SOURCES TO MONITOR

sbp.org.pk — monetary policy, financial stability, forex
nepra.org.pk — tariff, FCA, determinations
ogra.org.pk — wellhead price, retail price notifications
secp.gov.pk — corporate regulatory changes
psx.com.pk — company announcements (tier 1 real-time)
finance.gov.pk — fiscal data, PSDP, budget
imf.org/pakistan — program reviews
apcma.com.pk — cement dispatches
pama.org.pk — auto sales
aptma.org.pk — textile exports
nfdc.gov.pk — fertilizer offtake
pbs.gov.pk — CPI, LSM, trade data
