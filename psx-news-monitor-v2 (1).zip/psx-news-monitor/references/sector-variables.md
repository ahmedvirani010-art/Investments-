# Sector Variables — PSX Impact Matrix

Full mapping of macro/sector variables to affected PSX tickers, direction of impact, and transmission mechanism.
Load this file for SCAN and SCREEN queries, and for any query where sector variable coverage could be incomplete from recall.

---

## TABLE OF CONTENTS

A. Universal Variables (affect all or most sectors)
B. Banking
C. Energy — E&P
D. Energy — Refining
E. Energy — OMC
F. Energy — IPP
G. Fertilizer
H. Cement
I. Pharma
J. Auto Assemblers
K. Textiles
L. Cross-Sector Contagion Map

---

## A. UNIVERSAL VARIABLES

These affect virtually all PSX-listed companies and must appear in every SCAN output.

1. SBP POLICY RATE
Direction: Rate cut = broadly bullish for equities (lower discount rate, cheaper borrowing).
Direct beneficiaries: Banks (short-term NIM impact depends on asset-liability mix), leveraged companies (lower finance cost).
Direct losers: None systemically — but rate cut signal implies inflation under control, net positive.
Key threshold: Each 100 bps cut expands market P/E capacity by approximately 0.8-1.2x historically.
Tickers most sensitive: MCB, HBL, UBL (asset-sensitive), HUBC, KAPCO (leveraged IPPs), LUCK (capex financing).

2. PKR/USD RATE
PKR depreciation = mixed across sectors.
Winners: E&P (USD-denominated wellhead prices), Fertilizer (import substitute — urea priced vs. import parity), Textiles (export revenues).
Losers: Refiners (crude import cost), OMCs (inventory working capital), Pharma (API imports), Auto (CBU/CKD imports), Cement (coal imports), IPPs (USD-denominated fuel costs passed through but creates circular debt risk).
Key threshold: Every PKR 10 depreciation vs. USD = approximately +PKR 3-5 EPS for OGDC, approximately +PKR 8-12 EPS for POL, approximately -PKR 5-8 EPS for ATRL (net of inventory position), approximately -PKR 2-3 EPS for PSO (working capital cost).

3. IMF PROGRAM STATUS
Failure / suspension = systemic risk, PKR devaluation, market-wide selloff.
Active/on-track = floor under PKR, macro stability, supports equity valuation.
New tranche disbursement = bullish signal, eases BOP pressure.
Tickers most sensitive: All, but especially those with USD cost exposure (refiners, OMCs, pharma, auto).

4. PAKISTAN CPI / REAL RATES
High inflation + high policy rate = equity discount rates elevated = P/E compression.
Declining CPI trend = rate cut expectations = equity re-rating trigger.
Tickers most sensitive: Banking (NIM trajectory), Growth names (SEARL, HIGHNOON).

5. PSDP DISBURSEMENT / GOVERNMENT SPENDING
PSDP acceleration = cement demand signal.
Public sector salary increase = consumer demand uplift (auto, FMCG adjacent).
Tickers most sensitive: LUCK, DGKC, MLCF, FCCL (cement), INDU, PSMC (auto).

---

## B. BANKING

Key variables and ticker map.

1. SBP POLICY RATE — RATE DIRECTION AND PACE
Asset-sensitive banks benefit more from rate cuts (faster repricing of assets vs. liabilities).
MCB, HBL: high CASA ratios = structurally lower funding cost = net positive across cycles.
UBL: international operations add FX exposure layer.
MEBL: Islamic profit-sharing mechanics delay but don't eliminate rate sensitivity.
Magnitude guide: 100 bps cut = approximately +3-5% impact on asset-sensitive bank NIM; liability-sensitive = flat to slightly negative near term.

2. PIB/TBILL YIELD CURVE
Longer-dated PIBs = mark-to-market gain when rates fall. Banks heavy in long-duration PIBs benefit most.
HBL, MCB historically held large PIB portfolios. Check latest quarterly disclosures for current duration mix.
Inversion or steepening signals: Watch 3M T-Bill vs. 10Y PIB spread.

3. CASA RATIO (BANK-SPECIFIC, BUT MONITOR SYSTEM-WIDE TREND)
System CASA declining = banks forced to expensive term deposits = NIM pressure.
SBP data release on deposit growth = signal.

4. LOAN GROWTH AND NPL TRENDS
SBP credit data (monthly) = proxy for private sector activity.
Rising NPLs = provision charges = earnings drag. Manufacturing sector NPL spike hits MCB (industrial lending), NBP (public sector).
Watch: SBP Financial Stability Review, quarterly FSR.

5. ADVANCE TAX / SUPER TAX NOTIFICATIONS
Banking sector carries elevated super tax. Any change = direct EPS impact.
Every 1% change in effective tax rate = approximately 1.5-2% impact on reported EPS across large banks.

Tickers: HBL, UBL, MCB, ABL, NBP, MEBL, BAHL, BAFL

---

## C. ENERGY — E&P

1. CRUDE OIL PRICE (BRENT/WTI/ARAB LIGHT)
Most direct EPS variable for E&P.
OGDC: ~60% gas, ~40% liquids. Oil price sensitivity lower than POL due to gas weight.
POL: oil-heavy (Attock field). More levered to crude.
PPL: large gas volumes. Crude price secondary.
Magnitude: USD 10/bbl Brent move = approximately PKR 3-5/share OGDC EPS, approximately PKR 8-12/share POL EPS (verify current production mix).

2. OGRA WELLHEAD PRICE NOTIFICATIONS
OGRA sets wellhead gas prices via pricing framework linked to international benchmarks.
Notification date: typically semi-annual. Watch OGRA press releases.
Direction: upward revision = direct revenue increase for OGDC, PPL, POL, MARI.
Magnitude: PKR 50/MMBTU gas price increase ≈ approximately PKR 2-3/share OGDC EPS (approximate, verify volumes).

3. PKR/USD (see Universal)
All E&P revenues linked to USD-denominated benchmark prices, received in PKR.
PKR depreciation = revenue uplift (USD price × higher PKR rate).

4. CIRCULAR DEBT — GOVERNMENT RECEIVABLES
OGDC and PPL carry multi-hundred-billion circular debt receivables from GOP/SNGPL/SSGCL.
New circular debt increase = cash flow quality deterioration despite high reported earnings.
Watch: Ministry of Energy monthly circular debt flow statement.

5. EXPLORATION SUCCESS / PRODUCTION UPDATES
Well announcement (dry hole vs. discovery) = company-specific catalyst.
Production guidance revision = forward EPS change.
Watch: PSX company announcements (tier 1 disclosure).

Tickers: OGDC, PPL, POL, MARI

---

## D. ENERGY — REFINING

1. CRACK SPREADS (REFINING MARGIN)
Product price (diesel/petrol/furnace oil) minus crude input cost = gross refining margin.
Singapore complex margin = reference. Pakistan refiners typically at discount to Singapore due to simple/semi-complex configuration (except NRL/ATRL post-upgrade).
Magnitude: USD 1/bbl crack spread change = approximately PKR 0.5-1/share ATRL EPS (verify throughput).

2. CRUDE OIL PRICE LEVEL (INVENTORY GAIN/LOSS)
Rising crude = inventory gain (buy cheap, sell expensive finished product). Falling crude = inventory loss.
This is the largest single source of earnings volatility for ATRL/NRL.
Key analytical note: Always normalize ATRL/NRL earnings by removing inventory gain/loss. Underlying throughput margin is the real indicator.
Magnitude: USD 10/bbl crude move over a quarter with ~15-day crude inventory = approximately PKR 3-6/share inventory impact for ATRL (approximate; depends on inventory volume).

3. EURO-5 UPGRADE POLICY (ATRL-SPECIFIC)
ATRL's Euro-5 upgrade project is a structural re-rating catalyst. Monitor: timeline announcements, capex updates, OGRA approval status.
Completion = higher-value product slate, better crack spread, reduced fuel oil output (lowest margin product).

4. OGRA PRODUCT PRICE NOTIFICATIONS
Domestic petrol/diesel prices set by OGRA (effectively GOP). Price cap suppresses margin if crude rises.
Watch fortnightly OGRA/PPRA price notifications.

5. PKR/USD (see Universal)
Crude imported in USD. PKR depreciation = cost inflation for refiners unless domestic prices adjusted proportionally.
Attock group (ATRL) has Attock crude discount (~5-10% vs. Arab Light) as structural cost advantage — monitor if this relationship changes.

Tickers: ATRL, NRL, PRL, CNERGY

---

## E. ENERGY — OMC

1. MOTOR FUEL MARGIN (OGRA NOTIFICATION)
OGRA sets OMC dealer and OMC margins per liter. Fixed margin model (not volume × price spread).
Margin revision upward = direct revenue per liter increase.
Watch: OGRA price notifications (fortnightly).
APL vs PSO distinction: APL benefits from Attock group supply chain (preferred crude allocation). PSO is volume leader but carries higher circular debt receivables risk.

2. VOLUME THROUGHPUT (PAMA DATA INDIRECT, PBIF DATA DIRECT)
Industry fuel volumes = OMC revenue base.
Watch: OCAC (Oil Companies Advisory Committee) monthly data. Also PAMA auto sales as demand proxy.

3. CIRCULAR DEBT — RECEIVABLES FROM POWER SECTOR
PSO carries largest circular debt exposure. Receivables from WAPDA/DISCOs create cash flow drag.
PSO-specific risk: financing cost on receivables suppresses FCF significantly.

4. PKR/USD (see Universal)
OMCs purchase crude/products in USD equivalent. Working capital cost inflates with PKR depreciation.
PSO most exposed (largest volumes). APL partially insulated by Attock supply efficiency.

Tickers: PSO, APL, HASCOL

---

## F. ENERGY — IPP

1. NEPRA TARIFF NOTIFICATIONS
IPPs earn on capacity payment (fixed) + energy payment (variable, fuel cost pass-through).
Capacity payment linked to USD LIBOR/SOFR + PKR component. USD portion re-rates with PKR.
NEPRA determination = rate of return on equity confirmed or revised.
Watch: NEPRA monthly determination orders and annual generation license reviews.

2. CIRCULAR DEBT / GOVERNMENT PAYMENT DELAYS
IPPs most operationally affected sector by circular debt. Capacity payments delayed = cash flow crisis.
HUBC, KAPCO: largest listed IPPs, most exposed to payment delays.
Watch: Ministry of Energy monthly circular debt flow statement. Any government IPP settlement plan = positive catalyst.

3. FUEL COST PASS-THROUGH TIMELINESS
RLNG, HFO, coal fuel costs theoretically passed through to tariff. Timing mismatch creates under-recovery.
Watch: NEPRA fuel cost adjustment (FCA) monthly determinations.

4. PKR/USD ON CAPACITY PAYMENTS
USD-denominated capacity payments translate at higher PKR → higher PKR revenues when PKR weakens.
Net effect: PKR depreciation is net positive for USD-indexed IPPs (HUBC) if fuel costs are also passed through.

5. COAL PRICE (for coal-based IPPs like HUBC Port Qasim unit)
Coal price spike → potential under-recovery if FCA delayed.

Tickers: HUBC, KAPCO, NCPL, LALPIR, SAPM, FKPCL

---

## G. FERTILIZER

1. NATURAL GAS FEEDSTOCK PRICE (RLNG vs. DEDICATED GAS)
Gas feedstock is 60-70% of urea production cost.
EFERT: newer plant, lower gas consumption per tonne = cost leader.
FFC: larger, older plant but fully dedicated gas allocation historically.
FFBL: DAP production adds phosphate/sulphur cost exposure.
Watch: SSGCL/SNGPL gas price notifications, RLNG import price (linked to crude).

2. UREA SELLING PRICE (DOMESTIC + EXPORT PARITY)
Domestic urea price regulated by government (NFDC/Ministry of Food).
Export parity price = import parity cap (what it would cost to import = ceiling on domestic price).
When domestic price < import parity = healthy demand, no government subsidy pressure.
Watch: NFDC price circulars, international urea benchmark prices (Middle East FOB).

3. GIDC (GAS INFRASTRUCTURE DEVELOPMENT CESS)
Contingent liability for FFC, EFERT, FFBL. Supreme Court rulings have periodically created large one-time charges.
Watch: Any Supreme Court bench listing on GIDC case.

4. CROP SEASON CALENDAR AND OFFTAKE DATA
Kharif (June-September planting) and Rabi (October-January planting) = peak urea demand periods.
Off-season = inventory build, potential price softness.
Watch: NFDC monthly offtake data. PBS crop production estimates.

5. PKR/USD (for export and import parity pricing)
PKR depreciation raises import parity → ceiling on domestic price rises → pricing power improves.

Tickers: FFC, EFERT, FFBL, FATIMA, DAWH

---

## H. CEMENT

1. COAL PRICE (INTERNATIONAL)
Coal is 35-50% of cement production cost. Imported coal (South African, Indonesian) priced in USD.
Coal price spike = margin compression unless cement price increased.
Magnitude: USD 10/MT coal move = approximately PKR 15-25 impact on cement cost/tonne (verify fuel blend ratio).
LUCK: WHR (Waste Heat Recovery) reduces coal dependence = structural cost advantage.
Watch: ICE Newcastle coal futures, Indonesian coal benchmark (ICI).

2. CEMENT RETAIL PRICE (DOMESTIC)
Domestic retail price = revenue driver. Pricing power strongest in construction season (March-June, September-November).
All-Pakistan cement price trend: watch APCMA monthly data.
Watch: APCMA monthly dispatches, cement dealer network price lists.

3. DISPATCHES DATA (APCMA MONTHLY)
Volume = capacity utilization = operating leverage.
Industry dispatch increase → earnings leverage, especially for high-fixed-cost plants.
Export dispatches (Afghanistan, India if open) = additional volume signal.
Watch: APCMA press release (first week of each month).

4. PSDP AND CONSTRUCTION ACTIVITY
Government infrastructure spending (PSDP) drives bulk cement demand.
Housing starts, CPEC-related civil work = demand tailwind.
Watch: Finance Division PSDP utilization reports (quarterly).

5. PKR/USD (for coal import cost)
Coal imported in USD. PKR depreciation = cost inflation.
North zone companies (LUCK, DGKC, MLCF) carry higher logistics cost from port = slightly more exposed.

6. GAS/POWER AVAILABILITY
Gas load shedding affects kiln operations. Power outages create production disruption.
Watch: SNGPL/SSGCL gas curtailment notices, NTDC power situation.

Tickers: LUCK, DGKC, MLCF, FCCL, CHCC, KOHC, PIOC, GWLC

---

## I. PHARMA

1. DRAP PRICE NOTIFICATIONS
Drug Regulatory Authority of Pakistan controls retail prices for essential/controlled drugs.
Price increase notification = direct revenue uplift.
Delays in price notification create margin compression vs. rising input costs.
Watch: DRAP gazette notifications, Ministry of Health circulars.

2. API (ACTIVE PHARMACEUTICAL INGREDIENT) IMPORT COST
Most Pakistan pharma companies import APIs from China/India.
PKR depreciation = API cost inflation → margin squeeze unless DRAP price adjustment follows.
SEARL: higher branded generic mix = better pricing power. HIGHNOON: FDA-compliant facility (Project FORCE) will reduce import dependency longer-term.
Watch: PKR/USD (primary input cost driver).

3. FDA/EU APPROVAL EVENTS (HIGHNOON-SPECIFIC)
HIGHNOON's Project FORCE (SEZ, FDA/EU-compliant greenfield facility) = export market access trigger.
Any FDA inspection, approval, or product filing update = re-rating catalyst specific to HIGHNOON.
Watch: HIGHNOON PSX announcements, FDA import alert database.

4. HEALTHCARE BUDGET AND NHSP PROCUREMENT
National procurement volumes for essential medicines = revenue for manufacturers with government contracts.
Watch: Finance Act healthcare allocation, NHSP tender awards.

Tickers: SEARL, HIGHNOON, FEROZ, ABOT, GLAXO

---

## J. AUTO ASSEMBLERS

1. PAMA MONTHLY SALES DATA
Most important monthly data release for auto sector. Volume = revenue proxy.
Released: first week of each month for prior month.
Cars: INDU (Honda), PSMC (Suzuki), HCAR (Toyota). Trucks/tractors: separate data.
Watch: PAMA press release.

2. CBU/CKD IMPORT DUTIES AND REGULATORY FRAMEWORK
Duty structure changes = cost and competitive dynamics shift.
EDB (Engineering Development Board) policy on localization = structural factor.
Watch: FBR SRO notifications, EDB policy updates.

3. PKR/USD ON CKD COST
CKD kits imported in USD/JPY. PKR depreciation = direct cost inflation.
INDU (Honda Japan sourcing) vs. PSMC (Suzuki/Pak Suzuki mix). Cost pass-through to consumer depends on demand elasticity.

4. AUTO FINANCING RATES (LINKED TO SBP RATE)
Car financing is the largest demand driver. High rates suppress financed purchases.
SBP rate cut = significant auto demand uplift (lagged 1-2 quarters).
Watch: SBP auto financing data in Monthly Statistical Bulletin.

5. CONSUMER CONFIDENCE / REAL INCOME
Macro improvement = auto upgrade cycle. Stagnation = down-trading.
Watch: PBS household income surveys, remittance data (consumer income proxy).

Tickers: INDU, PSMC, HCAR, MTL, AGTL

---

## K. TEXTILES

1. PKR/USD
Export revenues in USD, costs mostly in PKR. PKR depreciation = revenue boost in PKR terms.
Most important single variable for textile earnings translation.

2. EXPORT ORDERS AND GLOBAL DEMAND
US/EU retail order book = forward revenue visibility.
Watch: APTMA (textile association) monthly export data, PBS large-scale manufacturing.

3. COTTON PRICE AND AVAILABILITY
Cotton lint = primary raw material for spinning/composite mills.
Domestic crop (Kharif harvest October-December): good crop = lower input cost.
International cotton (Cotlook A Index): determines import parity.
Watch: PCCC crop reports, Cotlook A Index.

4. ENERGY COST (GAS + POWER)
Energy-intensive sector. Gas load shedding = production disruption.
RLNG pricing vs. dedicated gas allocation = cost differential between mills.
Watch: SNGPL load shedding schedule, captive power vs. grid sourcing mix.

5. EXPORT REBATES AND SRO BENEFITS
Government textile support packages (DLTL, TUFS, zero-rated sales tax status) = margin support.
Watch: FBR SRO notifications on textile-specific benefits.

Tickers: NML, ILP, GATM, NCL

---

## L. CROSS-SECTOR CONTAGION MAP

For systemic events, these chains must be flagged in analysis:

CIRCULAR DEBT DETERIORATION (government payables increase):
→ E&P receivables increase (OGDC, PPL, POL) → cash flow quality falls despite earnings
→ IPP capacity payment delays (HUBC, KAPCO) → liquidity strain, potential bank debt drawdown
→ OMC receivables increase (PSO) → working capital cost rises, finance charges erode profit
→ Banking sector NPL risk (loans to PSO, IPPs) → provision charge risk (NBP most exposed)

PKR SHARP DEVALUATION (>5% rapid move):
→ Import-cost sectors hurt: Refining, OMCs, Pharma, Auto, Cement (coal)
→ Export and USD-revenue sectors helped: E&P, Fertilizer, Textiles
→ Banking: short-term PKR liquidity strain but USD revaluation of foreign assets
→ All: discount rate applied to equity rises (PKR devaluation usually accompanied by rate concerns)

SBP RATE CUT CYCLE (100 bps or more):
→ Banking NIM impact: asset-sensitive banks (MCB, HBL) initially benefit on loan repricing
→ PIB portfolio mark-up: banks holding long-duration PIBs report MTM gains
→ Auto demand uplift (lagged 2-3 quarters as financing rates fall)
→ Construction and cement demand uplift (property market activity rises)
→ Discount rate compression → P/E expansion for growth names (SEARL, HIGHNOON, INDU)

IMF PROGRAM DISRUPTION:
→ PKR devaluation risk (BOP pressure) → contagion across import sectors
→ Fiscal tightening → PSDP cuts → cement demand decline
→ Interest rate spike risk → banking NIMs volatile, equity discount rates rise
→ Market-wide de-rating: risk premium expands across all sectors

CRUDE OIL SPIKE (>USD 10/bbl rapid):
→ E&P revenue uplift (OGDC, PPL, POL, MARI)
→ Refiner inventory gain (short-term) then margin pressure if pass-through delayed
→ OMC working capital cost rise, potential under-recovery (PSO)
→ IPP fuel cost rise → potential NEPRA FCA delay → circular debt increase
→ Fertilizer gas cost pressure (RLNG linked to crude)
→ Broader inflation pass-through → CPI impact → SBP rate expectations
