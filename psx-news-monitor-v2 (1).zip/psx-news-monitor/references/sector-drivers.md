# Sector Revenue & Cost Drivers — PSX P&L Framework

Load this file when asked to analyze sector margins, earnings quality, or when a SCAN/SCREEN query requires understanding how news flows into sector P&Ls rather than just variable-to-ticker direction.

This file answers: **What builds the income statement of each sector, line by line?**

---

## TABLE OF CONTENTS

A. Banking
B. Energy — E&P
C. Energy — Refining
D. Energy — OMC
E. Energy — IPP
F. Fertilizer
G. Cement
H. Pharma
I. Auto Assemblers
J. Textiles
K. Chemicals (EPCL, ICI, NIMIR, LOTCHEM)
L. Earnings Quality Flags (cross-sector)

---

## A. BANKING

### Revenue Drivers
1. **Net Interest Income (NII)** — Primary revenue line. = Earning Assets × Net Interest Margin (NIM).
   - NIM = Yield on Assets minus Cost of Funds
   - Yield on assets driven by: SBP policy rate (variable-rate loans reprice), T-Bill/PIB yield curve (investment book), loan mix (consumer vs. corporate vs. SME)
   - Cost of funds driven by: CASA ratio (higher CASA = cheaper funding), term deposit competition, interbank rate
   - Key sensitivity: MCB and HBL have high CASA (>50%) = structural NIM advantage. MEBL's Islamic structure uses profit-sharing rates, which lag conventional rate moves by 1-2 quarters.
   - Rule of thumb: 100 bps SBP rate cut → NIM compresses ~15-25 bps for asset-sensitive banks in the near term; liability-sensitive banks see NIM improvement.

2. **Non-Interest Income** — Fee income, FX gain/loss, gain on securities, dividend income.
   - FX income: UBL benefits from international operations (remittance corridors).
   - Securities gain: Banks holding long-duration PIBs report MTM gains when rates fall. This is a one-time gain, not recurring — always normalize for it.
   - Fee income: Trade finance, remittances, card income. Relatively stable.

3. **Loan Growth** — Volume × spread = revenue growth engine.
   - Private sector credit growth from SBP data = leading indicator for bank topline.
   - Corporate vs. consumer loan mix matters: consumer (higher spread, higher NPL risk), corporate (lower spread, lower risk).

### Cost Drivers
1. **Provisions / Credit Losses** — Single largest earnings risk factor.
   - NPL ratio rise → provision charge → direct EPS hit.
   - Sectors to watch for NPL contagion: textiles (export slowdown), construction (project delays), SME (energy cost stress).
   - Each 1% rise in NPL ratio system-wide typically adds PKR 5-10bn in provisions across the large-5 banks collectively (approximate).

2. **Operating Expenses (OpEx)** — Staff costs, branch network, IT.
   - Inflation-linked: high CPI = wage pressure. Banks with large branch networks (HBL, NBP) are more OpEx-heavy.
   - Cost-to-Income ratio: MCB historically best-in-class (~35-40%); NBP highest (~60%+) due to public sector bloat.

3. **Tax** — Super tax on banking sector is structurally elevated. Any change = direct EPS impact.
   - Current super tax rate: 10% on banking income (verify current budget year).
   - Every 1% change in effective tax rate ≈ 1.5-2% impact on reported EPS.

### Key Margin Formula
> NIM (%) = (Interest Income − Interest Expense) / Average Earning Assets × 100
> ROE = PAT / Average Equity (target: >20% for top-tier banks in Pakistan)

---

## B. ENERGY — E&P

### Revenue Drivers
1. **Production Volumes** — Barrels of oil equivalent per day (BOEpd). Volume × price = gross revenue.
   - OGDC: ~60% gas, ~40% liquids. Gas volumes relatively stable; oil volumes decline without new wells.
   - POL: Oil-heavy (Attock Potohar fields). Most price-sensitive E&P on oil.
   - PPL: Large gas producer (Sui fields). Revenue more stable but gas price revision is key catalyst.
   - MARI: Dominant gas supplier to Fauji Fertiliser. Captive offtake = revenue visibility.

2. **Realized Oil Price** — Linked to Arab Light / Dubai crude benchmark, set by OGRA. PKR-denominated.
   - Formula: Revenue = Production Volume (bbl) × [Arab Light USD/bbl × PKR/USD] × OGRA pricing factor
   - Discount to benchmark: Pakistan E&P receives ~90-95% of Arab Light for crude. Verify current OGRA notification.

3. **Realized Gas Price** — OGRA wellhead notification. Set semi-annually. Less volatile than oil but step-changes on notification.
   - Current wellhead gas price: check OGRA website for latest notification (PKR/MMBTU).
   - High-BTU fields (MARI, Sui) receive premium pricing.

4. **Other Income** — Processing charges, condensate, LPG extraction. Minor for OGDC/PPL, material for POL (Attock Refinery affiliate income).

### Cost Drivers
1. **Operating & Lifting Costs** — Typically USD 4-8/BOE for Pakistan E&P (low-cost basin).
   - Inflation-linked: pumping, maintenance, staff. Generally <15% of revenue at $70+ crude.
   - POL has structurally low lifting costs due to shallow, mature fields.

2. **Depletion, Depreciation & Amortization (DD&A)** — Non-cash but large. Tied to proved reserve base.
   - Rising DD&A = reserve depletion signal. Watch in quarterly accounts.

3. **Exploration Write-offs** — Dry hole cost charged to P&L. Binary risk on exploration wells.

4. **Royalties & Levies** — Government take. ~12.5% royalty on oil; ~12.5% on gas. Regulated.

5. **Finance Cost** — OGDC and PPL are net-cash companies. Minimal finance cost. POL has modest borrowings.

### Key Earnings Sensitivity
> USD 10/bbl crude move = ~PKR 3-5/share OGDC EPS; ~PKR 8-12/share POL EPS
> PKR 50/MMBTU gas price increase = ~PKR 2-3/share OGDC EPS
> PKR 10 depreciation vs. USD = ~PKR 3-5/share OGDC; ~PKR 8-12/share POL

### Earnings Quality Flag
⚠️ **Circular Debt Adjustment**: OGDC and PPL report high PAT but carry PKR 500-700bn+ in circular debt receivables. FCF (cash from operations) is materially lower than reported earnings. Always ask: "What is cash collected vs. billed?"

---

## C. ENERGY — REFINING

### Revenue Drivers
1. **Throughput Volume** — Barrels processed per day × product slate value.
   - ATRL (Attock Refinery): ~50,000 bpd capacity, simple/semi-complex.
   - NRL (National Refinery): ~65,000 bpd, more complex, lube oil production = premium product.

2. **Gross Refining Margin (GRM)** — The core spread.
   - GRM = Weighted average realized product price − Crude input cost (per barrel)
   - Pakistan GRM benchmark: Singapore complex minus ~USD 1-3/bbl discount (due to simpler configuration).
   - NRL benefits from lube base oil production = structurally higher GRM.

3. **Inventory Gain / Loss** — The dominant earnings swing factor.
   - Rising crude = buy crude cheap, sell finished products at higher prices during the period = inventory gain.
   - Falling crude = inventory loss.
   - This is NOT recurring profit. **Always normalize ATRL/NRL earnings by stripping inventory gain/loss.**
   - Approximate: USD 10/bbl crude move over a quarter on ~15-day inventory = PKR 3-6/share ATRL impact.

4. **Attock Crude Discount** (ATRL-specific) — Attock fields supply crude at ~5-10% discount to Arab Light. Structural cost advantage for ATRL.

### Cost Drivers
1. **Crude Acquisition Cost** — Largest cost line. 85-90% of revenue in most periods.
   - Paid in USD (import parity). PKR depreciation = cost inflation unless domestic product prices adjust.

2. **Energy / Utilities** — Fuel, power for refinery operations. ~3-5% of revenue.

3. **Maintenance / Turnaround** — Planned maintenance shutdowns create volume loss quarters. Watch for turnaround announcements.

4. **Finance Cost** — Working capital financing for crude inventory. Rises with SBP rate and inventory value.

### Key Margin Formula
> GRM (USD/bbl) = Realized Product Price (blended) − Crude Cost − Operating Expenses per barrel
> Normalized EPS = Reported EPS ± Inventory Gain/Loss per share (after tax)

---

## D. ENERGY — OMC

### Revenue Drivers
1. **Volume Throughput** — Litres of petrol/diesel/HFO/HOBC distributed.
   - PSO: ~55-60% market share. Volume leader.
   - APL: ~10-12% share. Premium segment focus, Attock supply advantage.

2. **OMC Margin per Litre** — Set by OGRA. Fixed margin model.
   - Current OMC margin: check latest OGRA notification (approximately PKR 7-10/litre for petrol/diesel, verify current).
   - Margin revision = direct revenue per litre change. Volume × revised margin = revenue uplift/hit.

3. **Dealer Margin** — Paid to retail stations. OMCs retain the OMC margin only (not dealer margin).

4. **Lube / Grease / Aviation Fuel** — Higher margin specialty products. APL has stronger position here.

5. **Storage and Throughput Fees** — Infrastructure income. Relatively stable.

### Cost Drivers
1. **Product Procurement Cost** — Buy from refineries/imports at ex-refinery price.
   - PSO: largest importer of petroleum products. Working capital need = large.
   - Rising crude → rising procurement cost → working capital stress → higher finance cost (circular hit on PAT).

2. **Distribution and Logistics** — Trucking, pipeline access, storage. Relatively fixed.

3. **Finance Cost on Working Capital** — Critical for PSO.
   - PSO borrows PKR 200-400bn short-term to finance inventory and circular debt.
   - 100 bps SBP rate change = approximately PKR 2-4bn annual finance cost change for PSO.

4. **Circular Debt Receivables Financing Cost** — PSO receives delayed payment from power sector.
   - Each PKR 100bn increase in receivables at 10.5% = ~PKR 10.5bn annual finance charge.
   - This is the primary reason PSO's reported PAT is far lower than its gross margin suggests.

### Key Margin Formula
> OMC Net Margin per Litre = OGRA OMC Margin − Operating Cost − Finance Cost (working capital) per litre
> PSO FCF = PAT + DD&A − Working Capital Increase (often negative due to circular debt build)

---

## E. ENERGY — IPP

### Revenue Drivers
1. **Capacity Payments** — Fixed revenue regardless of dispatch. Largest component (~70-80% of revenue).
   - USD-indexed for older IPPs (HUBCO, KAPCO under NEPRA 1994 policy).
   - PKR depreciation = capacity payment revenue increases in PKR terms (positive for USD-indexed IPPs if fuel costs are also passed through).
   - Formula: Capacity Payment = Installed Capacity (MW) × NEPRA-notified rate (PKR/kW/month)

2. **Energy Payments** — Variable. Fuel cost pass-through + O&M variable component.
   - Fuel cost is supposed to be 100% passed through to NEPRA tariff. Timing delays create under-recovery.

3. **NEPRA Tariff Revisions** — Periodic review of RoE, O&M costs. Material for RoE determination.

### Cost Drivers
1. **Fuel Cost** — Gas, RLNG, HFO, coal depending on plant type.
   - HUBCO: HFO + coal (Port Qasim). Coal price = direct cost driver.
   - KAPCO: RLNG-heavy. RLNG price linked to crude.
   - Theoretically passed through, but timing mismatch = real cash flow risk.

2. **Finance Cost** — IPPs are highly leveraged (project finance). Rates matter significantly.
   - HUBCO: significant PKR-denominated long-term debt. SBP rate cut = finance cost reduction.

3. **Circular Debt — Cash Collection** — Capacity payments receivable from CPPA/NTDC. Payment delays = cash flow risk even if P&L shows revenue accrual.

### Key Earnings Quality Flag
⚠️ **HUBCO and KAPCO**: Reported PAT may look healthy; examine CPPA receivables. If receivables growing >PKR 10bn/quarter, FCF is deteriorating despite earnings.

---

## F. FERTILIZER

### Revenue Drivers
1. **Urea Selling Price** — Domestic price regulated; set relative to import parity.
   - When international urea is high → domestic import parity price ceiling rises → companies can raise prices.
   - FFC: largest urea producer (~2.3mn tonnes/year), prices near domestic ceiling.
   - Rule of thumb: PKR 100/bag domestic urea price change = ~PKR 2-3/share FFC EPS.

2. **Sales Volume** — Linked to crop calendar. Kharif (June-Sept) and Rabi (Oct-Jan) are peak demand seasons.
   - NFDC monthly offtake data = forward volume signal.
   - Export volumes: when domestic market is oversupplied and international price is favorable, companies export. This is lumpy.

3. **DAP/NP Revenue** (FFBL, EFERT) — Phosphate/NP fertilizer priced at import parity. International DAP price = direct revenue driver for FFBL.

4. **Other Income** — FFC has significant investment portfolio (FFC Energy, FCCL stakes). Dividend income from affiliates can be 10-15% of PAT.

### Cost Drivers
1. **Natural Gas Feedstock** — 60-70% of variable cost.
   - Dedicated gas (MARI → FFC pipeline): cheaper, approximately PKR 400-600/MMBTU (verify OGRA notification).
   - RLNG (spot market): PKR 1,500-2,500/MMBTU depending on crude price.
   - EFERT: newer, more efficient plant = lower gas consumption per tonne of urea. Cost advantage vs. FFC on a per-unit basis.
   - Gas price increase of PKR 100/MMBTU = ~PKR 1.5-2.5/share FFC EPS impact (approximate).

2. **Packing Material** — HDPE bags. Minor but petrochemical-linked.

3. **Distribution and Dealer Margins** — Fixed per tonne. Relatively stable.

4. **GIDC Provision** — Contingent liability. Supreme Court rulings can trigger large one-time charges.

### Key Margin Formula
> Gross Margin per Tonne = Urea Selling Price (PKR/bag × 50kg) − Gas Cost per tonne − Packing − Other Variable
> Current spread: When urea price is PKR 2,000+/bag and gas cost is ~PKR 500/MMBTU (dedicated), FFC gross margin per tonne is structurally wide.

---

## G. CEMENT

### Revenue Drivers
1. **Dispatches Volume** — Tonnes sold × price per tonne.
   - APCMA monthly data = single most important data point for cement sector.
   - Local dispatches: construction activity, PSDP, housing.
   - Export dispatches: Afghanistan (primary), occasional India border trade.

2. **Cement Retail Price** — Set by market dynamics, not government. Seasonal pattern: strong March-June (construction season), weak July-August (monsoon).
   - All-Pakistan retail price: check APCMA data. Currently approximately PKR 1,050-1,100/bag (50kg) — verify current.
   - North vs. South zone price differential: North zone (LUCK, DGKC) typically commands premium.

3. **LUCK Premium** — Lucky Cement has structural advantages: WHR (Waste Heat Recovery = ~30% power cost reduction), large-scale captive power, regional distribution network.

### Cost Drivers
1. **Coal** — Largest variable cost. 35-50% of total production cost.
   - International coal (South African, Indonesian): USD 70-120/MT range (verify current). Imported in USD.
   - PKR depreciation = direct coal cost inflation.
   - LUCK: WHR reduces coal consumption per tonne of clinker. Structural cost advantage.
   - Rule of thumb: USD 10/MT coal move = PKR 15-25 cost impact per tonne of cement (approximate; depends on fuel blend ratio and kiln efficiency).

2. **Energy (Power & Gas)** — 15-20% of production cost.
   - Power tariff (NEPRA) or captive power (RLNG, coal): LUCK's WHR reduces this significantly.
   - Gas load shedding = production disruption → operating leverage loss.

3. **Packaging (HDPE bags)** — ~PKR 50-70/bag. Crude-linked.

4. **Freight and Distribution** — Significant for long-haul dispatches. Diesel price = cost driver.
   - Rs. 55/litre diesel hike = material freight cost increase for all cement companies.

5. **Finance Cost** — Cement sector is capex-heavy (new plants). LUCK, DGKC have material borrowings. SBP rate = direct impact on capex-linked debt servicing.

### Key Margin Formula
> EBITDA per tonne = Retail Price − Coal Cost/tonne − Power Cost/tonne − Freight/tonne − Overhead/tonne
> Current industry EBITDA/tonne target range: PKR 1,200-1,800/tonne for well-run plants (LUCK upper end)

---

## H. PHARMA

### Revenue Drivers
1. **Domestic Sales Volume** — Prescription volume × price per unit.
   - DRAP price notification = direct revenue uplift for regulated products.
   - SEARL: strong branded generic portfolio in high-volume therapeutic areas. Pricing power is better than commodity generics.
   - HIGHNOON: FDA/EU-compliant facility = future export revenue catalyst (Project FORCE).

2. **Export Revenue** — Currently small for most listed companies. HIGHNOON's Project FORCE is the structural export play.
   - Export priced in USD: PKR depreciation = export revenue uplift.

3. **Government Procurement (NHSP / EPI)** — Bulk tenders. Low margin but high volume. Bidding calendar drives quarterly lumpiness.

4. **OTC and Consumer Health** — Less price-regulated. Higher margin. ABOT (Abbot) has strong OTC portfolio.

### Cost Drivers
1. **Active Pharmaceutical Ingredients (APIs)** — 40-60% of cost of goods sold.
   - Sourced from China, India, and Europe. Paid in USD/EUR.
   - PKR depreciation = direct API cost inflation.
   - HIGHNOON's Project FORCE reduces long-term API import dependency.

2. **Packaging Materials** — Glass vials, blister packs, cartons. Minor.

3. **Regulatory & Compliance Costs** — DRAP registration fees, pharmacovigilance, GMP compliance. Rising for export-grade companies.

4. **Distribution and Promotion** — Pharma reps, doctor outreach, trade margins. 15-20% of revenue for branded companies.

### Key Margin Flag
⚠️ **Price vs. Input Cost Lag**: DRAP price increases often lag API cost inflation by 6-12 months. During this lag, gross margin compresses. Watch for margin recovery following a DRAP price notification.

---

## I. AUTO ASSEMBLERS

### Revenue Drivers
1. **Vehicle Sales Volume** — Units sold × invoice price.
   - PAMA monthly data = primary revenue indicator.
   - INDU (Honda): Civic, City, BR-V. Mid-to-premium segment.
   - PSMC (Suzuki): Alto, Cultus, Wagon-R. High-volume economy segment. More volume-sensitive.
   - HCAR (Toyota): Corolla, Yaris, Fortuner. Premium segment, higher margin per unit.

2. **Invoice Price** — Can be revised upward to pass through input cost increases (CKD/CBU import cost). Market acceptance depends on demand elasticity.
   - Price revisions typically announced with 2-4 weeks notice. Watch company PSX announcements.

3. **Parts and Accessories Revenue** — After-market and dealer network income. Relatively stable.

4. **Other Income / Investment Income** — Auto assemblers often have large cash/investment balances. High SBP rates → significant other income. Rate cut = other income compression.
   - For INDU specifically: other income from investments can be 15-20% of PAT at high policy rates.

### Cost Drivers
1. **CKD (Completely Knocked Down) Kit Cost** — 60-70% of production cost.
   - Imported in USD (from Japan for Honda/Toyota; from Japan/China for Suzuki).
   - PKR depreciation = direct, immediate CKD cost inflation.
   - Rule of thumb: 5% PKR depreciation → ~3-5% gross margin compression unless price is raised.

2. **Local Content** — Domestically sourced components (glass, tyres, batteries, seats).
   - Higher local content = lower USD exposure. Suzuki has more local content than Honda/Toyota.
   - Inflation in Pakistan = local component cost inflation.

3. **Indirect Costs (Utilities, Factory Overhead)** — Energy costs. Gas/electricity availability matters for production scheduling.

4. **Warranty Provisions** — Accrual-based. Rising quality issues = provision charge.

### Key Demand Driver
> Auto financing rate (SBP rate + bank spread) is the single most important demand driver.
> Auto financing typically offered at SBP rate + 2-4%. At 10.5% SBP rate, financed car cost is ~12-15% annualized → suppresses demand significantly vs. a 5-7% rate environment.
> Rule of thumb: 100 bps SBP rate cut → 5-8% uplift in financed auto sales (lagged 2-3 months).

---

## J. TEXTILES

### Revenue Drivers
1. **Export Revenue (USD)** — Primary revenue driver. Converted at prevailing PKR/USD.
   - PKR depreciation = direct PKR revenue uplift.
   - US and EU order book = forward revenue visibility. Watch APTMA monthly export data.
   - High-Value-Added (HVA) textiles (garments, made-ups): higher USD/kg revenue than commodity yarn.
   - NML: diversified across spinning, fabric, and garments. Lower single-segment exposure.

2. **Domestic Sales** — Secondary. Margins lower than export. But demand from FMCG/apparel domestic market provides base load.

3. **Export Rebates / DLTL** — Government support scheme. Material to margin (approximately PKR 3-8/kg equivalent). Any change = direct EPS impact.

### Cost Drivers
1. **Cotton Raw Material** — 40-55% of revenue for spinning/composite mills.
   - Domestic cotton (Punjab/Sindh Kharif harvest): October-December arrivals.
   - Import parity cotton (Cotlook A Index in USD) = price ceiling from imports.
   - Good domestic crop = lower cotton price = margin improvement for spinners.
   - Rule of thumb: 10% cotton price decline = ~2-4% gross margin improvement for composite mills.

2. **Energy (Gas + Power)** — 15-25% of production cost. Most energy-intensive sector after cement.
   - Gas load shedding = production shutdown = operating leverage loss.
   - RLNG curtailment in winter = major risk for mills not on dedicated gas.
   - Captive power (independent gas/coal-fired generators): mills with captive power are structurally advantaged.

3. **Labour / Wages** — 10-15% of cost. Inflation-linked. Minimum wage revisions (federal/provincial) = cost increase.

4. **Freight and Export Logistics** — Container rates (USD-denominated). Disruptions (Suez Canal, Red Sea) affect delivery timelines.

### Key Margin Formula
> Gross Margin = Export Revenue per kg (USD × PKR/USD) + Rebate − Cotton Cost/kg − Energy Cost/kg − Labour/kg − Freight/kg
> Currently: PKR stability despite oil shock has neutralized the traditional PKR depreciation tailwind for textiles.

---

## K. CHEMICALS

Tickers: **EPCL** (Engro Polymer & Chemicals), **ICI** (ICI Pakistan), **NIMIR** (Nimir Industrial Chemicals), **LOTCHEM** (Lotte Chemical Pakistan)

### Sub-sector Split
Pakistan's listed chemicals fall into three distinct sub-segments with different driver fingerprints:

| Sub-Segment | Primary Tickers | Core Product | Key Input |
|---|---|---|---|
| PVC / Chlor-Alkali | EPCL, LOTCHEM | PVC resin, caustic soda, EDC | Ethylene (naphtha-linked), salt, power |
| Specialty / Life Science | ICI | Polyurethanes, soda ash, paints, seeds | Propylene oxide, soda ash imports |
| Industrial Chemicals | NIMIR | Textile auxiliaries, surfactants | Fatty acids, caustic soda, LAB |

---

### EPCL — Engro Polymer & Chemicals

#### Revenue Drivers
1. **PVC Resin Price (Domestic)** — Largest revenue line. Domestic PVC price tracks import parity (CFR Karachi from China/SE Asia).
   - When international PVC price rises → import parity rises → EPCL can raise domestic price → revenue uplift.
   - Key relationship: CFR China PVC price (USD/MT) × (1 + import duty + freight) × PKR/USD = import parity ceiling on domestic price.
   - Current import duty on PVC: ~10-16% (verify latest FBR SRO). Any duty change = direct competitive moat change.

2. **Caustic Soda Revenue** — Co-product of chlor-alkali process. Sold to textile, pharma, soap industries.
   - Caustic soda demand linked to: textile sector activity (largest consumer), soap manufacturing, pharma.
   - Price: domestic market rate. No direct import parity link (heavy, low-value-to-weight ratio limits imports).

3. **EDC / VCM Sales** — Ethylene Dichloride and Vinyl Chloride Monomer are intermediates. Sold when not fully consumed internally.
   - EPCL's PVC capacity expansion has reduced surplus EDC/VCM available for sale.

4. **Volume Throughput** — Plant utilization rate × nameplate capacity.
   - EPCL nameplate PVC capacity: ~195,000 MT/year (verify latest capacity after expansion).
   - Construction sector activity = PVC demand (pipes, fittings, cables, flooring).
   - PSDP spending → housing/infrastructure → PVC pipe demand.

#### Cost Drivers
1. **Ethylene Feed Cost** — Largest variable cost. ~40-50% of PVC production cost.
   - EPCL sources ethylene from ENGRO Fertilizers (LPG route) and imports.
   - Ethylene price is naphtha-linked → crude oil price = upstream driver.
   - Rule of thumb: USD 10/bbl crude move → ~USD 15-20/MT ethylene cost change → ~PKR 2-3/share EPCL EPS impact (approximate, verify current production volumes).

2. **Power and Utilities** — Chlor-alkali is extremely power-intensive (electrolysis process).
   - Power tariff (NEPRA) = direct cost driver. EPCL has captive power partially.
   - Gas load shedding / power outages = plant shutdown risk.
   - Rule of thumb: PKR 1/unit power tariff increase = ~PKR 0.5-1/share EPCL EPS drag.

3. **Salt (NaCl) Feed** — Low cost, domestically sourced. Not a material margin driver.

4. **PKR/USD on Ethylene Imports** — Ethylene imports paid in USD. PKR depreciation = cost inflation.
   - Partially offset by PVC import parity rising (both cost and revenue ceiling move together on PKR depreciation).

#### Key Earnings Sensitivity
> USD 50/MT PVC price increase (domestic) on ~195,000 MT/year = ~PKR 9.75bn revenue uplift (pre-cost) → ~PKR 3-4/share EPS (approximate, after tax and minority)
> Net PKR depreciation effect: broadly neutral to slightly positive — import parity ceiling rises with PKR fall, partly offsetting ethylene cost increase.

#### Key Earnings Quality Flag
⚠️ **Inventory Gain/Loss on Ethylene**: EPCL carries ethylene inventory. Crude price movements create inventory gains/losses similar to refiners. Normalize for this in quarterly EPS analysis.

---

### ICI Pakistan

#### Revenue Drivers
1. **Polyurethanes (PU) Segment** — Largest revenue contributor. MDI (methylene diphenyl diisocyanate) sourced from BASF/Huntsman, distributed in Pakistan.
   - Pure distribution margin business. Revenue = volume sold × spread over import cost.
   - Construction and foam manufacturing demand = volume driver (furniture, insulation, mattresses).
   - MDI international price (USD/MT) + PKR/USD = landed cost → ICI marks up for local distribution.

2. **Soda Ash Segment** — ICI Pakistan manufactures soda ash (sodium carbonate) via Solvay process at Khewra.
   - Customers: glass manufacturers, detergent companies, textiles (dyeing), paper.
   - Domestic soda ash price tracks import parity (Chinese soda ash CFR Karachi).
   - Import duty on soda ash (verify FBR SRO — historically 10-15%) = protection for domestic producers.

3. **Life Sciences (Seeds / Agri-inputs)** — ICI distributes seeds, crop protection chemicals.
   - Revenue linked to crop season calendar. Kharif (March-May planting) = peak demand.
   - Margins thin; volume-driven segment.

4. **Animal Health / Specialty Chemicals** — Distribution of veterinary and industrial chemicals.
   - Niche, relatively stable margins.

#### Cost Drivers
1. **MDI Import Cost** — Largest cost line for PU segment. Paid in USD.
   - PKR depreciation = direct MDI cost inflation. Passed through to customers but with a lag.

2. **Energy for Soda Ash Manufacturing** — Natural gas + power. Gas price notification = direct cost driver.
   - SNGPL gas allocation for Khewra plant. Any curtailment = production disruption.

3. **Limestone / Salt Inputs** — Domestically sourced for soda ash. Inflation-linked but minor.

4. **Distribution Overhead** — Large salesforce for Life Sciences and specialty segments.

#### Key Margin Flag
⚠️ **Segment Mix Matters**: ICI's PU segment margin is distribution-thin (2-4%). Soda ash has better manufacturing margin (15-25%) but is capacity-constrained. Life Sciences is low-margin volume. Always decompose ICI PAT by segment — headline revenue growth can mislead if it's PU-driven.

---

### NIMIR Industrial Chemicals

#### Revenue Drivers
1. **Textile Auxiliary Chemicals** — Surfactants, sizing agents, finishing chemicals sold to textile mills.
   - Volume directly linked to textile sector activity and capacity utilization.
   - PKR export-linked textile boom = higher NIMIR volumes.

2. **Caustic Soda / Bleaching Agents** — Sold to textile, paper, food processing industries.

3. **Sulphuric Acid and Industrial Intermediates** — Sold to fertilizer and chemical industries.

#### Cost Drivers
1. **Fatty Acid / LAB Imports** — Key raw materials for surfactants. Imported, USD-denominated.
   - PKR depreciation = direct raw material cost inflation.

2. **Energy** — Process heat and power. Gas price and availability = key cost driver.

3. **Caustic Soda Input (for some product lines)** — Priced domestically; EPCL is a supplier.

#### Key Earnings Quality Flag
⚠️ NIMIR is a small-cap with thin float. Earnings quality and disclosure standards are lower than EPCL/ICI. Use with caution for position sizing.

---

### LOTCHEM — Lotte Chemical Pakistan

#### Revenue Drivers
1. **PTA (Purified Terephthalic Acid)** — Core product. Sold to polyester/PET manufacturers.
   - International PTA price (CFR Pakistan, USD/MT) = domestic price benchmark.
   - PTA demand linked to: polyester yarn (textiles), PET bottles (beverages/FMCG), packaging.
   - Key downstream customer: textile sector (polyester blend yarns).

2. **Export Revenue** — LOTCHEM exports PTA when domestic market is oversupplied.
   - USD-denominated export revenue = PKR depreciation is positive.

#### Cost Drivers
1. **Paraxylene (PX) Feed** — Single largest cost. 75-80% of PTA production cost.
   - PX is a naphtha derivative, directly linked to crude oil price.
   - PX sourced from LOTCHEM's Korean parent (Lotte Chemical) via long-term supply agreement — provides some pricing stability.
   - Rule of thumb: USD 50/MT PX price increase → ~USD 40/MT PTA cost increase (PX-to-PTA conversion ratio ~0.67) → significant margin compression.

2. **Power and Utilities** — PTA production is energy-intensive. NEPRA tariff = cost driver.

3. **PKR/USD on PX Imports** — PX imported in USD. PKR depreciation = cost inflation.
   - Offset: domestic PTA price rises with import parity (both sides move with PKR).

#### PTA Spread — The Core Margin Metric
> PTA Spread (USD/MT) = PTA Market Price − PX Cost × 0.67 − Processing Cost
> Watch: Asian PTA-PX spread (published by ICIS, Platts). When spread narrows below USD 50-60/MT, LOTCHEM earnings deteriorate sharply.

#### Key Earnings Quality Flag
⚠️ **PTA Spread Volatility**: LOTCHEM earnings are almost entirely determined by the PTA-PX spread, which can swing ±USD 80-100/MT within a single quarter. Normalize for spread cycle position before forming a valuation view.

---

### Chemicals Sector — Macro Variable Map

| Variable | Direction | Affected Tickers | Mechanism |
|---|---|---|---|
| Crude oil price ↑ | Negative | EPCL, LOTCHEM | Ethylene / PX feed cost rises |
| PKR depreciation | Mixed | All | Import parity ceiling rises (revenue) + import cost rises (cost) — net: roughly neutral to slightly positive for EPCL/LOTCHEM |
| NEPRA power tariff ↑ | Negative | EPCL (most), LOTCHEM | Power-intensive electrolysis / PTA process |
| Textile sector activity ↑ | Positive | EPCL (caustic soda, PVC), NIMIR, LOTCHEM (PTA) | Higher chemical offtake from mills |
| Construction activity / PSDP ↑ | Positive | EPCL (PVC pipes) | Infrastructure PVC demand |
| PVC import duty change | Critical | EPCL, LOTCHEM | Competitive moat vs. cheap Chinese imports |
| PTA-PX spread compression | Negative | LOTCHEM | Core margin destruction |
| Soda ash import duty change | Critical | ICI Pakistan | Protects domestic manufacturing margin |
| Gas price / RLNG notification | Negative | ICI (soda ash plant), NIMIR | Process energy cost |
| International chemical prices (PVC, PTA, MDI) | Variable | All | Import parity pricing ceiling |

### Watch Sources for Chemicals
- ICIS (icis.com) — PVC, PTA, PX, MDI, caustic soda pricing
- Platts (spglobal.com) — Asian chemical spreads
- FBR SRO notifications — import duty changes on PVC, soda ash, PTA
- EPCL, LOTCHEM, ICI quarterly accounts — segment margin decomposition
- APCMA/APTMA data — downstream demand signal

---

## L. EARNINGS QUALITY FLAGS (Cross-Sector)

When analyzing any sector, always check for these distortions before forming an EPS-based view:

| Sector | Distortion | What to Normalize |
|---|---|---|
| Banking | PIB mark-to-market gains | Strip one-time securities gain from recurring NII |
| Banking | Super tax change | Adjust PAT for tax rate change to get underlying earnings |
| E&P | Circular debt receivables | Use FCF yield, not earnings yield, for valuation |
| Refining | Inventory gain/loss | Report normalized GRM-based EPS |
| OMC | Circular debt finance cost | FCF often negative despite reported PAT |
| IPP | CPPA receivables build | Check cash collected vs. capacity payment billed |
| Fertilizer | GIDC one-time charge/reversal | Strip GIDC from recurring earnings |
| Cement | Utilization leverage | Below 70% utilization = fixed cost drag, normalize for cycle |
| Auto | Other income at high rates | Strip investment income when rate cycle changes |
| Pharma | DRAP price lag | Gross margin in adjustment period is not representative |
| Chemicals (EPCL/LOTCHEM) | Inventory gain/loss on feedstock | Normalize for ethylene/PX inventory moves |
| Chemicals (LOTCHEM) | PTA-PX spread cycle | Mid-cycle spread ≠ normalized earnings; use through-cycle spread |
| Chemicals (ICI) | Segment mix distortion | Decompose by PU / soda ash / life sciences before forming EPS view |

---

## HOW TO USE THIS FILE IN ANALYSIS

When a news event hits, use the appropriate sector section to trace the impact through the full P&L:

1. Identify which **revenue driver** or **cost driver** is being affected
2. Estimate the magnitude using the sensitivity formulas provided
3. Cross-check against the sector-variables.md variable-to-ticker map
4. Flag earnings quality issues that might distort the reported impact
5. Produce the final position action signal with quantified magnitude

Example workflow:
> News: "Coal prices rise USD 15/MT" → Cement sector → Cost Driver #1 (Coal) → PKR 22/MT cost increase → LUCK partially insulated by WHR → DGKC, MLCF more exposed → Urgency: THIS WEEK (USD 15/MT threshold per trigger-thresholds.md) → REDUCE DGKC, HOLD LUCK
