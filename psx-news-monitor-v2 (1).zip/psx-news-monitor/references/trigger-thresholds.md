# Trigger Thresholds — Urgency Classification for PSX News Monitor

## URGENCY DEFINITIONS

IMMEDIATE — Warrants same-day portfolio review and potential position action
THIS WEEK — Material event; review within 2-3 trading sessions
WATCH — Monitor for escalation; no immediate action required
NOISE — No material EPS or valuation impact; informational only

---

## UNIVERSAL THRESHOLDS

| Variable | IMMEDIATE | THIS WEEK | WATCH | NOISE |
|---|---|---|---|---|
| SBP policy rate change | Any announced change | Rate decision meeting day | Pre-meeting commentary | Survey/speculation without MPC signal |
| PKR/USD single session | >2% move | 1-2% move | 0.5-1% move | <0.5% move |
| PKR/USD cumulative MTD | >5% move | 3-5% move | 1-3% move | <1% move |
| IMF program | Suspension / missed review | New tranche disbursement | Review dates approach | Routine staff-level statements |
| Pakistan CPI print | >2% surprise vs. estimate | >1% surprise | In-line but trend change | In-line with consensus |
| PSDP disbursement | >PKR 100bn single tranche | Quarterly PSDP utilization data | Budget allocation changes | Political announcements without budget line |

---

## SECTOR-SPECIFIC THRESHOLDS

### BANKING
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| SBP MPC decision | Any rate change | Day of decision | Pre-MPC week |
| Banking sector super tax / advance tax change | Any SRO | Budget speech | Pre-budget speculation |
| System NPL ratio | >1% spike quarterly | Rising trend | Stable but elevated |
| T-Bill cutoff vs. expectation | >50 bps surprise | >25 bps surprise | Direction change |

### E&P / REFINING / OMC
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| Brent crude single session | >USD 5/bbl | USD 3-5/bbl | USD 1-3/bbl |
| OGRA wellhead price notification | Any notification | Expected revision window | Government signals |
| OGRA product price notification | Any fortnightly notification | — | — |
| Circular debt monthly flow | >PKR 50bn increase | PKR 20-50bn increase | Any increase | 
| Major field production update | Discovery / dry hole | Quarterly production guidance | Drilling activity |
| Attock crude allocation change | Any change | — | Contract renewal period |

### IPP
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| NEPRA tariff determination | Any issued | Due/expected | Appeal filed |
| Government IPP payment settlement | Any cabinet approval | Negotiations reported | Dispute reported |
| Circular debt monthly report | IPP-specific delay data | — | — |
| NEPRA FCA monthly determination | >PKR 2/unit surprise | Any FCA | — |

### FERTILIZER
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| GIDC Supreme Court hearing | Adverse order | Hearing scheduled | Case listed |
| Government urea price notification | Any notification | Seasonal review expected | Subsidy discussion |
| RLNG price notification | Any revision | — | Crude-linked adjustment |
| Urea international price | >USD 50/MT move MTD | USD 25-50/MT | USD 10-25/MT |
| NFDC monthly offtake | >20% YoY deviation | >10% YoY deviation | Direction change |

### CEMENT
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| APCMA monthly dispatch data | >20% YoY deviation | >10% YoY deviation | Direction change |
| Coal price move | >USD 15/MT MTD | USD 7-15/MT | USD 3-7/MT |
| PSDP large allocation/cut | >PKR 100bn revision | Quarterly review | Budget speech |
| Government construction moratorium | Any announcement | — | — |

### PHARMA
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| DRAP price revision notification | Any gazette | Expected review | Ministry deliberations |
| API import duty change | Any SRO | Budget | Pre-budget leaks |
| HIGHNOON FDA/EU update | Any approval/rejection | Inspection date | Filing progress |
| NHSP tender award | Major tender result | Bidding deadline | RFP issued |

### AUTO
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| PAMA monthly sales data | Release day (first week) | — | — |
| Import duty SRO | Any FBR SRO on auto duties | Budget | Pre-budget |
| CKD/CBU policy change | Any EDB notification | — | EDB meeting |
| PKR/USD (CKD cost) | >3% MTD | 1-3% | <1% |

### TEXTILES
| Variable | IMMEDIATE | THIS WEEK | WATCH |
|---|---|---|---|
| DLTL / export rebate change | Any SRO | Budget | Pre-budget |
| Cotton crop estimate revision | >10% vs. prior estimate | 5-10% | Acreage data |
| PBS monthly export data | >20% YoY deviation | >10% deviation | Trend shift |
| RLNG curtailment for textiles | Any major curtailment | Seasonal risk period | Load management plan |

---

## WHAT CONSTITUTES NOISE (DO NOT FLAG AS ACTIONABLE)

1. Political statements without a specific regulatory/fiscal action attached
2. Rumours or unverified social media reports without PSX/SBP/NEPRA/OGRA source
3. Minor commodity moves within weekly range (crude ±USD 1-2, coal ±USD 3-5)
4. Routine renewal of existing approvals (standard license renewals, annual returns)
5. Analyst report upgrades/downgrades from local houses without new data
6. PSX trading suspensions for technical reasons unrelated to fundamentals
7. General macroeconomic commentary from politicians without policy binding
8. Minor PKR moves (<0.5% session) in a stable trend

Note: Flag items as NOISE explicitly in output. This trains the user to filter effectively.
