---
name: psx-news-monitor
description: >
  Maps PSX news, macro events, and regulatory announcements to specific tickers with EPS impact and urgency ratings. Triggers for: market update, news on X, what moved today, SBP/NEPRA/OGRA announcement, oil price impact, PKR move, IMF news, portfolio review, sector news, what should I watch, any catalyst. Produces: macro dashboard, ranked news-to-ticker impact map, sector heat map, position action flags (IMMEDIATE/WATCH/NOISE). Use whenever any macro or regulatory event could affect PSX positions.
---

# PSX News Monitor — Portfolio Intelligence Framework

---

## STEP 0: INTAKE

On receiving a news/monitoring query:

A. CLASSIFY THE QUERY TYPE
   - [SPOT] Single event: "what does X news mean for my positions"
   - [SCAN] Broad scan: "what's happening today / this week / market update"
   - [WATCH] Variable watch: "monitor X", "what should I track"
   - [SCREEN] Sector screen: "any news affecting banking / energy / cement"

B. EXTRACT POSITION CONTEXT
   Check userMemories for known holdings. If explicit tickers are mentioned in query, use those.
   If no holdings context available, produce sector-level impact analysis and flag: "Share your holdings for position-specific signals."

C. FETCH LIVE DATA
   Always fetch before writing. Use web_search for:
   - SBP policy rate (if rate-sensitive sectors in scope)
   - PKR/USD (always — affects all import-cost sectors)
   - Crude oil price (Brent/WTI) if energy, refining, OMC, fertilizer in scope
   - Any specific event mentioned in query
   Search queries to use: "Pakistan news today PSX", "[event keyword] Pakistan", "SBP monetary policy", "PKR dollar rate today", "Brent crude today"

D. LOAD SECTOR VARIABLE TABLES
   Read references/sector-variables.md for the full variable→ticker impact matrix.
   Read references/trigger-thresholds.md for what magnitude of change is actionable vs. noise.

---

## OUTPUT STRUCTURE

Produce output in this exact sequence. Use CAPS for section headers. No markdown bold, no bullet symbols. Numbered lists for all items. Blank line between sections.

---

NEWS INTELLIGENCE BRIEF
Date: [Today's date]
Query type: [SPOT / SCAN / WATCH / SCREEN]
Positions in scope: [List tickers or "Full sector scan"]

---

MACRO DASHBOARD

State current values for all relevant variables. Flag changes vs. prior period.

1. SBP Policy Rate: [X%] — [unchanged / up X bps / down X bps since last MPC]
2. PKR/USD: [X] — [X% move MTD]
3. Brent Crude: [USD X/bbl] — [X% move WTD]
4. Pakistan CPI (latest): [X%]
5. IMF Program Status: [current tranche / review status]
6. T-Bill 3M yield: [X%] — key for bank NIMs
7. RLNG/Gas price (if energy in scope): [latest OGRA notification]
8. Coal price (if cement/IPP in scope): [USD X/MT]
9. Urea/DAP price (if fertilizer in scope): [USD X/MT or PKR/bag domestic]
10. Cotton lint (if textiles in scope): [PKR/maund or USD/lb]

Add or drop variables based on sectors in scope. Always include 1-4 for any portfolio scan.

---

NEWS EVENTS — RANKED BY PORTFOLIO IMPACT

For each material news item found, produce one entry in this format:

[N]. [HEADLINE — your own words, not quoted]
Event type: [Macro / Regulatory / Sector-specific / Company-specific / Geopolitical]
Urgency: [IMMEDIATE / THIS WEEK / WATCH — see trigger-thresholds.md for definitions]
Affected sectors: [List]
Affected tickers (direct): [List with direction: OGDC ↑, PSO ↓]
Affected tickers (indirect): [List with direction and brief rationale]
Mechanism: [Explain precisely how this event flows into earnings, margins, or valuations. Name the formula where one exists. E.g., "SBP rate cut of 100 bps expands bank NIM by approximately X bps on variable-rate book; PIB portfolio re-marks upward; reduces discount rate applied to equity valuation."]
Magnitude estimate: [Approximate EPS or margin impact where quantifiable. Always flag as approximate. E.g., "USD 5/bbl crude drop reduces ATRL inventory gain by approximately PKR X/share on a forward quarter basis."]
Position action signal: [BUY / ADD / HOLD / REDUCE / SELL / WATCH — with one-sentence rationale]
Conflicting signals: [Note any counter-forces that complicate the directional call]

---

SECTOR HEAT MAP

Quick-scan table showing sector-level directional bias from today's news+macro.

Sector | Net signal | Key driver today | Top ticker affected
Banking | [↑ / ↓ / →] | [e.g., rate cut expectation] | [MCB]
E&P | [↑ / ↓ / →] | [e.g., crude move] | [POL]
Refining | [↑ / ↓ / →] | [e.g., crude + PKR] | [ATRL]
OMC | [↑ / ↓ / →] | [e.g., motor fuel margins] | [APL]
IPP | [↑ / ↓ / →] | [e.g., NEPRA notification] | [HUBC]
Fertilizer | [↑ / ↓ / →] | [e.g., gas price + urea offtake] | [FFC]
Cement | [↑ / ↓ / →] | [e.g., PSDP disbursement / coal] | [LUCK]
Pharma | [↑ / ↓ / →] | [e.g., DRAP price notification] | [SEARL]
Auto | [↑ / ↓ / →] | [e.g., PAMA sales / duties] | [INDU]
Textiles | [↑ / ↓ / →] | [e.g., export orders / PKR] | [NML]

Only include sectors in scope for the query. For SCAN queries, include all.

---

PORTFOLIO-LEVEL ACTION FLAGS (if holdings are known)

For each known position:

[TICKER] — [BUY / ADD / HOLD / REDUCE / SELL / WATCH]
Trigger: [Which news/variable is driving this flag]
Time horizon: [Immediate / 1-4 weeks / Medium term]
Key risk if wrong: [One sentence on what could invalidate the call]
Next catalyst to watch: [Specific date or event]

---

WATCH LIST — UPCOMING CATALYSTS

List events in the next 2-4 weeks that could materially move positions. Include:
1. SBP MPC meeting (next date if known)
2. Company result seasons (note if Q results are due)
3. IMF review/tranche dates
4. NEPRA/OGRA price notification cycles
5. PAMA monthly auto sales (first week of each month)
6. PBS inflation data release
7. Any announced government policy reviews
8. Crop season calendar items (cotton arrivals, wheat procurement)

---

ANALYTICAL NOTES

Any important caveats, data quality flags, or analytical limits. Always note:
- Which macro inputs were live-fetched vs. recalled from training (flag vintage)
- Any conflicting signals where the directional call is genuinely ambiguous
- Any positions where the analyst would want to see more information before acting

---

## RULES

RULE 1: NEVER PRODUCE OUTPUT WITHOUT FETCHING LIVE DATA FIRST
The value of this skill is real-time intelligence. Training data is stale. Always run web_search for current macro variables and any event-specific queries before writing a single word of analysis. Flag every figure with its source and vintage.

RULE 2: MAP EVERY EVENT TO TICKERS — NO ORPHAN HEADLINES
Every news item must conclude with affected tickers and a position action signal. A headline without a ticker-level implication is not actionable intelligence. If the connection is indirect or uncertain, state it explicitly and still name the most likely affected scripts.

RULE 3: QUANTIFY WHERE POSSIBLE, APPROXIMATE TRANSPARENTLY
Approximate impacts are far more useful than vague directionality. Use the sensitivity tables from the sector-analysis skill as your reference for magnitude estimates. Always label them "approximate" and cite the variable relationship (e.g., "based on ~USD 10/bbl = ~PKR X/share ATRL EPS relationship").

RULE 4: URGENCY CLASSIFICATION IS NON-NEGOTIABLE
Every event gets an urgency rating. IMMEDIATE = warrants same-day position review. THIS WEEK = material but not intraday. WATCH = monitor for escalation. Urgency escalation triggers: SBP rate decision, IMF disbursement/failure, PKR move >2% in single session, crude move >USD 5/bbl in single session, NEPRA/OGRA notification materially different from expectation, company-specific surprise (earnings, dividend, regulatory).

RULE 5: DISTINGUISH SIGNAL FROM NOISE
Not every news item is portfolio-relevant. Explicitly flag items as NOISE (no material EPS/valuation impact) when warranted. A political statement without regulatory follow-through is noise. A NEPRA tariff notification is signal. Train the user to distinguish.

RULE 6: CROSS-SECTOR CONTAGION AWARENESS
PSX sectors are tightly coupled through the energy payment chain. A circular debt deterioration is simultaneously negative for E&P receivables, OMC working capital, and IPP cash flow. Always note cross-sector knock-on effects for systemic events (PKR devaluation, SBP rate moves, IMF program disruption, energy price shocks).

RULE 7: POSITION-LEVEL OUTPUT WHEN HOLDINGS ARE KNOWN
Generic sector analysis is less valuable than position-specific signals. When the user's holdings are known from context or memory, always produce the Portfolio-Level Action Flags section and tailor the analysis to the specific weight each holding has in the known sectors.

RULE 8: IMF PROGRAM IS THE MACRO ANCHOR — ALWAYS ACKNOWLEDGE
Pakistan's equity market is structurally anchored to IMF program status. For any SCAN or broad macro query, always state the current IMF review/tranche status and note its implications for PKR stability and fiscal policy constraints, regardless of whether it appears in the day's headlines.

RULE 9: CITE SOURCES, FLAG UNCERTAINTY
For every live-fetched data point, note the source (SBP.org.pk, NEPRA notification, Bloomberg/Reuters cite, PSX announcement). For data that could not be verified live, write [unverified — check current]. Never present stale training data as current fact.

RULE 10: SECTOR VARIABLE COVERAGE IS EXHAUSTIVE
Read references/sector-variables.md before writing. The full variable map ensures no material driver is missed. Do not rely on recall for the complete variable-to-ticker matrix.

RULE 11: TRACE NEWS THROUGH THE P&L, NOT JUST TO A TICKER
When a news event affects a sector, use references/sector-drivers.md to trace it through the income statement: which revenue line or cost line is hit, what is the margin formula impact, and is the effect recurring or one-time? A direction signal (↑ or ↓) is not sufficient — always state the mechanism and approximate magnitude using the sensitivity formulas in sector-drivers.md. Flag any earnings quality distortion (inventory gains, circular debt, GIDC, PIB MTM) that could misrepresent the true earnings impact.

---

## TIER ROUTING

SPOT query ("what does X mean for PSX / my stock") →
  Produce: Macro Dashboard (relevant variables only) + single News Event entry + Portfolio Action Flag if holding is known. 300-500 words.

SCAN query ("market update / what's happening / weekly review") →
  Produce: Full output structure. 800-1,200 words.

WATCH query ("what variables should I track for sector X") →
  Read references/sector-variables.md and produce a curated variable watch list for the sector. 400-600 words.

SCREEN query ("any news on cement / banking / energy") →
  Produce: Sector Heat Map + all News Events for that sector + Watch List items. 600-900 words.
  Load references/sector-drivers.md for the relevant sector before writing the Mechanism and Magnitude fields.

---

## REFERENCE FILES

Read these before writing relevant sections:

references/sector-variables.md — Full variable → ticker impact matrix for all PSX sectors. Load for SCAN and SCREEN queries or when the sector variable set is unclear.

references/sector-drivers.md — Full P&L-level revenue driver and cost driver breakdown for every sector (Banking, E&P, Refining, OMC, IPP, Fertilizer, Cement, Pharma, Auto, Textiles). Load when: (a) quantifying margin or EPS impact of a news event, (b) analyzing earnings quality or FCF vs. PAT distortions, (c) answering SCREEN or SPOT queries that require tracing news through an income statement. Contains sector-specific sensitivity formulas and earnings quality flags. This is the deeper layer — sector-variables.md tells you direction; sector-drivers.md tells you mechanism and magnitude.

references/trigger-thresholds.md — Quantified thresholds for IMMEDIATE / THIS WEEK / WATCH urgency classification. Load for all queries to calibrate urgency ratings correctly.

references/regulatory-calendar.md — SBP MPC schedule, NEPRA review cycles, OGRA notification patterns, IMF review calendar, result season calendar. Load for Watch List section.
